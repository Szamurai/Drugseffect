Config = {}

Config.Framework = "esx" -- "esx" or "qbcore"

Config.Drugs = {
    ["weed_leaf"] = {
        label = "Weed",
        duration = 5,
        progressTime = 5,
        animation = { dict = "amb@world_human_smoking_pot@male@base", anim = "base" },
        effect = "cannabis_sky",
        effectStrength = 0.8,
        bonusEffects = { armor = 0, health = 20 }
    },
    ["cocaine"] = {
        label = "Kokain",
        duration = 5,
        progressTime = 5,
        animation = { dict = "mp_player_int_upperwank", anim = "mp_player_int_wank_01" },
        effect = "stormy_sky",
        effectStrength = 0.9,
        bonusEffects = { armor = 50, health = 0 }
    },
    ["heroin_syringe"] = {
        label = "Heroin",
        duration = 5,
        progressTime = 4,
        animation = { dict = "amb@world_human_aa_smoke@male@idle_a", anim = "idle_a" },
        effect = "flood",
        effectStrength = 0.9,
        bonusEffects = { armor = 0, health = 50 }
    },
    ["mdma_pill"] = {
        label = "Ecstasy",
        duration = 5,
        progressTime = 5,
        animation = { dict = "amb@world_human_aa_smoke@male@idle_a", anim = "idle_a" },
        effect = "party_sky",
        effectStrength = 0.7,
        bonusEffects = { armor = 30, health = 10 }
    },
    ["crystal_shard"] = {
        label = "Crystal",
        duration = 5,
        progressTime = 5,
        animation = { dict = "amb@world_human_aa_smoke@male@idle_a", anim = "idle_a" },
        effect = "crystal_sky",
        effectStrength = 0.7,
        bonusEffects = { armor = 30, health = 10 }
    },
    ["lsd_tab"] = {
        label = "LSD",
        duration = 5,
        progressTime = 5,
        animation = { dict = "amb@world_human_aa_smoke@male@idle_a", anim = "idle_a" },
        effect = "psychedelic_sky",
        effectStrength = 0.7,
        bonusEffects = { armor = 30, health = 10 }
    }
}

Config.Effects = {
    ["cannabis_sky"] = {
        screenEffect = "DrugsTrevorClownsFight", -- Chaotic, colorful
        weatherEffect = "OVERCAST"
    },
    ["stormy_sky"] = {
        screenEffect = "SwitchHUDIn", -- Fast, vibrant
        weatherEffect = "OVERCAST"
    },
    ["flood"] = {
        screenEffect = "DrugsDrivingOut", -- Slow, dazed
        weatherEffect = "OVERCAST"
    },
    ["crystal_sky"] = {
        screenEffect = "DrugsMichaelAliensFight", -- Intense, crazy
        weatherEffect = "OVERCAST"
    },
    ["psychedelic_sky"] = {
        screenEffect = "PPFilter", -- Colorful, psychedelic
        weatherEffect = "FOGGY"
    },
    ["party_sky"] = {
        screenEffect = "BeastLaunch", -- Vibrant, party-like
        weatherEffect = "EXTRASUNNY"
    }
}