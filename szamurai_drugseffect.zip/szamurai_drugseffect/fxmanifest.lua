fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Szamurai'
description 'Drug Effect Script (QBCore/ESX)'
version '5.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependencies {
    'progressBars',
    'qb-core'
}

escrow_ignore {
    'config.lua',
    'server.lua',
    'client.lua'
}