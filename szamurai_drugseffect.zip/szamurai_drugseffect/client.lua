if Config.Framework == "qbcore" then
    QBCore = exports["qb-core"]:GetCoreObject()
end

local isDrugActive = false
local soundId = nil

local function StopCurrentDrugEffect()
    if isDrugActive then
        StopAllScreenEffects()
        ClearWeatherTypePersist()
        SetWeatherTypeNowPersist("CLEAR")
        Wait(500)
        SetTimeScale(1.0)
        local playerPed = PlayerPedId()
        ResetPedMovementClipset(playerPed, 0.0)
        SetPedIsDrunk(playerPed, false)
        SetPedMotionBlur(playerPed, false)
        StopGameplayCamShaking(true)
        if soundId then
            StopSound(soundId)
            ReleaseSoundId(soundId)
            soundId = nil
        end
        isDrugActive = false
    end
end

RegisterNetEvent("drugs:usedrug")
AddEventHandler("drugs:usedrug", function(drugName)
    local drug = Config.Drugs[drugName]
    if not drug then 
        return 
    end

    StopCurrentDrugEffect()

    if Config.Framework == "esx" then
        ESX.ShowNotification("Drog használata folyamatban...")
    elseif Config.Framework == "qbcore" then
        QBCore.Functions.Notify("Drog használata folyamatban...", "info")
    end

    exports['progressBars']:startUI(drug.progressTime * 1000, "Drog fogyasztása...")

    local playerPed = PlayerPedId()
    RequestAnimDict(drug.animation.dict)
    while not HasAnimDictLoaded(drug.animation.dict) do
        Wait(100)
    end
    TaskPlayAnim(playerPed, drug.animation.dict, drug.animation.anim, 8.0, -8.0, -1, 0, 0, false, false, false)

    Wait(drug.progressTime * 1000)
    ClearPedTasks(playerPed)

    TriggerEvent("drugs:startDrugEffect", drugName)
end)

RegisterNetEvent("drugs:startDrugEffect")
AddEventHandler("drugs:startDrugEffect", function(drugName)
    local drug = Config.Drugs[drugName]
    local effect = Config.Effects[drug.effect]
    local playerPed = PlayerPedId()
    isDrugActive = true
    StartScreenEffect(effect.screenEffect, 0, true)
    RequestAnimSet("move_m@drunk@verydrunk")
    while not HasAnimSetLoaded("move_m@drunk@verydrunk") do
        Wait(100)
    end
    SetPedMovementClipset(playerPed, "move_m@drunk@verydrunk", 1.0)
    SetPedIsDrunk(playerPed, true)
    SetTimeScale(0.7) -- 70% speed
    SetPedMotionBlur(playerPed, true)
    ShakeGameplayCam("DRUNK_SHAKE", 1.0)
    if effect.weatherEffect then
        SetWeatherTypeNowPersist(effect.weatherEffect)
    end
    SetPedArmour(playerPed, math.min(GetPedArmour(playerPed) + drug.bonusEffects.armor, 100))
    SetEntityHealth(playerPed, math.min(GetEntityHealth(playerPed) + drug.bonusEffects.health, 200))

    soundId = GetSoundId()
    PlaySoundFrontend(soundId, "SELECT_MENU", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    Citizen.CreateThread(function()
        local startTime = GetGameTimer()
        local durationMs = drug.duration * 1000
        while GetGameTimer() - startTime < durationMs do
            if not isDrugActive then 
                return 
            end
            Wait(100)
        end
        StopCurrentDrugEffect()
    end)
end)
