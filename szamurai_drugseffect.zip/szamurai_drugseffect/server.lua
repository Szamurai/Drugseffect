if Config.Framework == "esx" then
    ESX = exports["es_extended"]:getSharedObject()
elseif Config.Framework == "qbcore" then
    QBCore = exports["qb-core"]:GetCoreObject()
end

for drugName, data in pairs(Config.Drugs) do
    if Config.Framework == "esx" then
        ESX.RegisterUsableItem(drugName, function(source)
            local xPlayer = ESX.GetPlayerFromId(source)
            if xPlayer.getInventoryItem(drugName).count > 0 then
                xPlayer.removeInventoryItem(drugName, 1)
                xPlayer.showNotification("Használtál egy " .. data.label .. "-t!")
                TriggerClientEvent("drugs:usedrug", source, drugName)
            else
                xPlayer.showNotification("Nincs nálad " .. data.label .. "!")
            end
        end)
    elseif Config.Framework == "qbcore" then
        QBCore.Functions.CreateUseableItem(drugName, function(source)
            local Player = QBCore.Functions.GetPlayer(source)
            if Player.Functions.GetItemByName(drugName) and Player.Functions.GetItemByName(drugName).amount > 0 then
                Player.Functions.RemoveItem(drugName, 1)
                TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items[drugName], "remove")
                Player.Functions.Notify("Használtál egy " .. data.label .. "-t!", "success")
                TriggerClientEvent("drugs:usedrug", source, drugName)
            else
                Player.Functions.Notify("Nincs nálad " .. data.label .. "!", "error")
            end
        end)
    end
end